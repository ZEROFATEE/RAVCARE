#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use tauri::State;
use serde::{Serialize, Deserialize};
use std::{fs, sync::Mutex};
use chrono::Utc;
use bcrypt::{hash, verify, DEFAULT_COST};

// ===================================
// ========== USER SYSTEM ============
// ===================================

#[derive(Debug, Serialize, Deserialize, Clone)]
struct User {
    id: i64,
    username: String,
    email: String,
    password_hash: String,
    is_admin: bool,
}

struct UserState {
    users: Mutex<Vec<User>>,
}
//
const USERS_FILE: &str = "../data/users.json";

fn load_users() -> Vec<User> {
    if let Ok(data) = fs::read_to_string(USERS_FILE) {
        serde_json::from_str(&data).unwrap_or_else(|_| vec![])
    } else {
        vec![]
    }
}
fn save_users(users: &Vec<User>) {
    if let Ok(json) = serde_json::to_string_pretty(users) {
        let _ = fs::write(USERS_FILE, json);
    }
}

#[tauri::command]
fn register_user(
    state: State<'_, UserState>,
    username: String,
    email: String,
    password: String,
) -> Result<String, String> {
    let mut users = state.users.lock().map_err(|e| e.to_string())?;

    if users.iter().any(|u| u.username == username || u.email == email) {
        return Err("Username or email already exists".into());
    }

    let new_id = (users.len() as i64) + 1;
    let hashed_password = hash(password, DEFAULT_COST).map_err(|e| e.to_string())?;

    let new_user = User {
        id: new_id,
        username,
        email,
        password_hash: hashed_password,
        is_admin: false,
    };

    users.push(new_user);
    save_users(&users);

    Ok("User registered successfully!".into())
}


#[tauri::command]
fn login_user(
    state: State<'_, UserState>,
    username: String,
    password: String,
) -> Result<String, String> {
    let users = state.users.lock().map_err(|e| e.to_string())?;

    if let Some(user) = users.iter().find(|u| u.username == username) {
        if verify(password, &user.password_hash).unwrap_or(false) {
            if user.is_admin {
                Ok("Admin login successful!".into())
            } else {
                Ok("User login successful!".into())
            }
        } else {
            Err("Invalid username or password".into())
        }
    } else {
        Err("Invalid username or password".into())
    }
}

// ===================================
// ========== INVENTORY ==============
// ===================================

#[derive(Debug, Serialize, Deserialize, Clone)]
struct InventoryItem {
    id: i64,
    name: String,
    amount: i64,
    last_edited: String,
}

struct InventoryState {
    items: Mutex<Vec<InventoryItem>>,
}

const INVENTORY_FILE: &str = "../data/inventory.json";

fn load_inventory() -> Vec<InventoryItem> {
    if let Ok(data) = fs::read_to_string(INVENTORY_FILE) {
        serde_json::from_str(&data).unwrap_or_else(|_| vec![])
    } else {
        vec![]
    }
}
fn save_inventory(items: &Vec<InventoryItem>) {
    if let Ok(json) = serde_json::to_string_pretty(items) {
        let _ = fs::write(INVENTORY_FILE, json);
    }
}

#[tauri::command]
fn get_inventory(state: State<'_, InventoryState>) -> Vec<InventoryItem> {
    state.items.lock().unwrap().clone()
}
#[tauri::command]
fn create_item(
    state: State<'_, InventoryState>,
    name: String,
    amount: i64,
) -> Result<String, String> {
    let mut items = state.items.lock().map_err(|e| e.to_string())?;
    let new_id = (items.len() as i64) + 1;

    let new_item = InventoryItem {
        id: new_id,
        name,
        amount,
        last_edited: Utc::now().date_naive().to_string(),
    };

    items.push(new_item);
    save_inventory(&items);

    Ok("Item created successfully".into())
}
#[tauri::command]
fn edit_item(
    state: State<'_, InventoryState>,
    id: i64,
    name: String,
    amount: i64,
) -> Result<String, String> {
    let mut items = state.items.lock().map_err(|e| e.to_string())?;

    if let Some(item) = items.iter_mut().find(|i| i.id == id) {
        item.name = name;
        item.amount = amount;
        item.last_edited = Utc::now().date_naive().to_string();
        save_inventory(&items);
        Ok("Item updated".into())
    } else {
        Err("Item not found".into())
    }
}
#[tauri::command]
fn search_items(state: State<'_, InventoryState>, query: String) -> Vec<InventoryItem> {
    let items = state.items.lock().unwrap();
    items
        .iter()
        .filter(|item| item.name.to_lowercase().contains(&query.to_lowercase()))
        .cloned()
        .collect()
}
#[tauri::command]
fn filter_items(state: State<'_, InventoryState>, filter_type: String) -> Vec<InventoryItem> {
    let mut items = state.items.lock().unwrap().clone();
    match filter_type.as_str() {
        "alphabetical" => items.sort_by(|a, b| a.name.to_lowercase().cmp(&b.name.to_lowercase())),
        "amountAsc" => items.sort_by(|a, b| a.amount.cmp(&b.amount)),
        "amountDsc" => items.sort_by(|a, b| b.amount.cmp(&a.amount)),
        _ => {}
    }
    items
}


#[tauri::command]
fn delete_item(state: State<'_, InventoryState>, id: i64) -> Result<String, String> {
    let mut items = state.items.lock().map_err(|e| e.to_string())?;

    // Find the index of the item to remove
    let initial_len = items.len();
    items.retain(|item| item.id != id); // Keep items whose ID does NOT match the given ID

    if items.len() < initial_len {
        save_inventory(&items);
        Ok("Item deleted successfully".into())
    } else {
        Err("Item not found".into())
    }
}


// ===================================
// ========== PATIENTS ===============
// ===================================

#[derive(Debug, Serialize, Deserialize, Clone)]
struct Patient {
    // PATIENT INFO
    id: i64,
    first_name: String,
    last_name: String,
    middle_name: String,
    address: String,
    date_of_birth: String,
    age: i64,
    gender: String,
    weight: f64,
    date_created: String,

    // HISTORY OF EXPOSURE
    date_of_exposure: String,
    type_of_bite: String,
    site_of_bite: String,
    biting_animal: String,
    category: String,
    previous_anti_rabies_vaccine: String,
    post_prophylaxis_type: String,
    pre_prophylaxis_type: String,
    booster_dose_type: String,
    flu_vacc_type: String,
    pneumonia_vac_type: String,
    hepa_b_type: String,
    tetanus_toxoid_checked: String,
   
    // ANTI-RABIES VACCINE
    generic_name: String,
    brand_name: String,
    route: String,

    // SCHEDULE
    schedule: String,
    day_zero_date: String, // The automatically displayed current day
    day_three_date: String, // Day 3
    day_seven_date: String, // Day 7
    day_fourteen_date: String, // Day 14
    day_thirty_date: String, // Day 30

    // MEDICAL HISTORY 
    prev_vacc: String,
    sec_prev_vacc: String,
    date_of_vacc: String,
    sec_date_of_vacc: String,
    allergies: String,
    sec_allergies: String,
    ill_oper: String,
    sec_ill_oper: String,
    assessment: String,

    last_appointment: Option<String>,
}

struct PatientState {
    patients: Mutex<Vec<Patient>>,
}

const PATIENT_FILE: &str = "../data/patients.json";

fn load_patients() -> Vec<Patient> {
    if let Ok(data) = fs::read_to_string(PATIENT_FILE) {
        // Handle parsing errors gracefully, defaulting to an empty vector
        serde_json::from_str(&data).unwrap_or_else(|_| vec![])
    } else {
        vec![]
    }
}

fn save_patients(patients: &Vec<Patient>) {
    if let Ok(json) = serde_json::to_string_pretty(patients) {
        let _ = fs::write(PATIENT_FILE, json);
    }
}

#[tauri::command]
fn get_patients(state: State<'_, PatientState>) -> Vec<Patient> {
    state.patients.lock().expect("Failed to lock patients").clone()
}

#[tauri::command]
fn create_patient(
    //Patient Information
    state: State<'_, PatientState>,
    first_name: String,
    last_name: String,
    middle_name: String,
    address: String,
    date_of_birth: String,
    age: i64,
    gender: String,
    weight: f64,

    // History of Exposure
    date_of_exposure: String,
    type_of_bite: String,
    site_of_bite: String,
    biting_animal: String,
    category: String,
    previous_anti_rabies_vaccine: String,
    post_prophylaxis_type: String,
    pre_prophylaxis_type: String,
    booster_dose_type: String,
    flu_vacc_type: String,
    pneumonia_vac_type: String,
    hepa_b_type: String,'

    //Anti-Rabies Vaccine
    generic_name: String,
    brand_name: String,
    route: String,
    schedule: String,
    tetanus_toxoid_checked: String,
    // Schedule
    day_three_date: String,
    day_seven_date: String,
    day_fourteen_date: String,
    day_thirty_date: String,

    // Medical History
    prev_vacc: String,
    sec_prev_vacc: String,
    allergies: String,
    sec_allergies: String,
    ill_oper: String,
    sec_ill_oper: String,
    assessment: String,
) -> Result<Patient, String> { // Return the full Patient struct on success
    let mut patients = state.patients.lock().map_err(|e| e.to_string())?;

    let now_date = Utc::now().date_naive().to_string();

    let new_patient = Patient {
        id: Utc::now().timestamp_millis(), // unique ID
        first_name,
        last_name,
        middle_name,
        address,
        date_of_birth,
        age,
        gender,
        weight,
        date_created: now_date.clone(),
        date_of_exposure,
        type_of_bite,
        site_of_bite,
        biting_animal,
        category,
        previous_anti_rabies_vaccine,
        post_prophylaxis_type,
        pre_prophylaxis_type,
        booster_dose_type,
        flu_vacc_type,
        pneumonia_vac_type,
        hepa_b_type,
        generic_name,
        brand_name,
        route,
        schedule,
        tetanus_toxoid_checked,
        day_zero_date: now_date, // Scheduled day automatically displays current day (Day 0)
        day_three_date,    
        day_seven_date,     
        day_fourteen_date, 
        day_thirty_date,    
        prev_vacc,
        sec_prev_vacc,
        allergies,
        sec_allergies,
        ill_oper,
        sec_ill_oper,
        assessment,

       
        last_appointment: None,
    };

    let patient_to_return = new_patient.clone();
    patients.push(new_patient);
    save_patients(&patients);

    // Return the newly created patient object to the frontend
    Ok(patient_to_return)
}

#[tauri::command]
fn edit_patient(
    state: State<'_, PatientState>,
    id: i64,
    first_name: String,
    last_name: String,
    middle_name: String,
    address: String,
    date_of_birth: String,
    age: i64,
    gender: String,
    weight: f64,
    date_of_exposure: String,
    type_of_bite: String,
    site_of_bite: String,
    biting_animal: String,
    category: String,
    previous_anti_rabies_vaccine: String,
    post_prophylaxis_type: String,
    pre_prophylaxis_type: String,
    booster_dose_type: String,
    flu_vacc_type: String,
    pneumonia_vac_type: String,
    hepa_b_type: String,
    generic_name: String,
    brand_name: String,
    route: String,
    schedule: String,
    tetanus_toxoid_checked: String,
    day_zero_date: String,
    day_three_date: String,
    day_seven_date: String,
    day_fourteen_date: String,
    day_thirty_date: String,
    prev_vacc: String,
    sec_prev_vacc: String,
    allergies: String,
    sec_allergies: String,
    ill_oper: String,
    sec_ill_oper: String,
    assessment: String,
) -> Result<String, String> {
    let mut patients = state.patients.lock().map_err(|e| e.to_string())?;
    if let Some(p) = patients.iter_mut().find(|p| p.id == id) {
        p.first_name = first_name;
        p.last_name = last_name;
        p.middle_name = middle_name;
        p.address = address;
        p.date_of_birth = date_of_birth;
        p.age = age;
        p.gender = gender;
        p.weight = weight;
        p.date_of_exposure = date_of_exposure;
        p.type_of_bite = type_of_bite;
        p.site_of_bite = site_of_bite;
        p.biting_animal = biting_animal;
        p.category = category;
        p.previous_anti_rabies_vaccine = previous_anti_rabies_vaccine;
        p.post_prophylaxis_type = post_prophylaxis_type;
        p.pre_prophylaxis_type = pre_prophylaxis_type;
        p.booster_dose_type = booster_dose_type;
        p.flu_vacc_type = flu_vacc_type;
        p.pneumonia_vac_type = pneumonia_vac_type;
        p.hepa_b_type = hepa_b_type;

        p.generic_name = generic_name;
        p.brand_name = brand_name;
        p.route = route;
        p.schedule = schedule;
        p.tetanus_toxoid_checked = tetanus_toxoid_checked;
        p.day_zero_date = day_zero_date;
        p.day_three_date = day_three_date;
        p.day_seven_date = day_seven_date;
        p.day_fourteen_date = day_fourteen_date;
        p.day_thirty_date = day_thirty_date;
        p.prev_vacc = prev_vacc;
        p.sec_prev_vacc = sec_prev_vacc;
        p.allergies = allergies;
        p.sec_allergies = sec_allergies;
        p.ill_oper = ill_oper;
        p.sec_ill_oper = sec_ill_oper;
        p.assessment = assessment;
        save_patients(&patients);
        Ok("Patient updated successfully.".into())
    } else {
        Err("Patient not found.".into())
    }
}


#[tauri::command]
fn search_patients(state: State<'_, PatientState>, query: String) -> Vec<Patient> {
    let patients = state.patients.lock().unwrap();
    patients
        .iter()
        .filter(|p| {
            let full_name = format!("{} {} {}", p.first_name, p.middle_name, p.last_name).to_lowercase();
            full_name.contains(&query.to_lowercase())
        })
        .cloned()
        .collect()
}

#[tauri::command]
fn filter_patients(state: State<'_, PatientState>, filter_type: String) -> Vec<Patient> {
    let mut patients = state.patients.lock().unwrap().clone();

    match filter_type.as_str() {
        // Sort alphabetically by last name
        "alphabetical" => patients.sort_by(|a, b| a.last_name.to_lowercase().cmp(&b.last_name.to_lowercase())),
        
        // Sort by date created (ascending)
        "dateAsc" => patients.sort_by(|a, b| a.date_created.cmp(&b.date_created)),
        
        // Sort by date created (descending / newest first)
        "dateDsc" => patients.sort_by(|a, b| b.date_created.cmp(&a.date_created)),

        _ => {}
    }

    patients
}



#[tauri::command]
fn delete_patient(state: State<'_, PatientState>, id: i64) -> Result<String, String> {
    let mut patients = state.patients.lock().map_err(|e| e.to_string())?;

    let initial_len = patients.len();
    patients.retain(|patient| patient.id != id);

    if patients.len() <initial_len {
        save_patients(&patients);
        Ok("Patient deleted successfully".into())
    } else {
        Err("Patient not found".into())
    }
}


// ===================================
// ========== MAIN APP ===============
// ===================================

fn main() {
    tauri::Builder::default()
        .manage(UserState {
            users: Mutex::new(load_users()),
        })
        .manage(InventoryState {
            items: Mutex::new(load_inventory()),
        })
        .manage(PatientState {
            patients: Mutex::new(load_patients()),
        })
        .invoke_handler(tauri::generate_handler![
            // user
            register_user,
            login_user,
            // inventory
            get_inventory,
            create_item,
            edit_item,
            delete_item,
            search_items,
            filter_items,
            // patients
            get_patients,
            create_patient,
            search_patients,
            filter_patients,
            edit_patient,
            delete_patient
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
