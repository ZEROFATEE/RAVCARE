// Prevents additional console window on Windows in release, DO NOT REMOVE!!
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

#[tauri::command]
fn get_dashboard_data() -> String {
    // Later, this will fetch from SQLite.
    // For now, return sample data as JSON.
    let data = r#"{
        "patients": 120,
        "appointments": 15,
        "queue": "Patient #5"
    }"#;
    data.to_string()
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![get_dashboard_data])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
