use serde::Serialize;
use tauri::command;

#[derive(Serialize)]
pub struct DashboardData {
    patients: i32,
    appointments: i32,
    queue: String,
}

#[command]
pub fn get_dashboard_data() -> DashboardData {
    DashboardData {
        patients: 120,
        appointments: 15,
        queue: "Patient #5".to_string(),
    }
}
