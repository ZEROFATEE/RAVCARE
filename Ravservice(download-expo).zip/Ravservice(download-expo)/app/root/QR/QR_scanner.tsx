import { View, Text } from 'react-native'
import React from 'react'

const QR_scanner = () => {
  return (
    <View>
      <Text>QR_scanner</Text>
    </View>
  )
}

export default QR_scanner