import { View, Text, Button, Alert, SafeAreaView } from 'react-native'
import React from 'react'

export default function home() {
  return (
    <SafeAreaView
       style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "#2b2929ff",
     }}
    >
        <Text style={{color: 'white', marginBottom: 20}}>Home Screen</Text>

        <Button
           title="QR_Scanner"
           color="#f194ff"
           onPress={() => Alert.alert('This is a button that goes to the QR Code')}  
    />
    </SafeAreaView>
  );
}




